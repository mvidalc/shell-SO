date
hola
sleep 1
pwd
